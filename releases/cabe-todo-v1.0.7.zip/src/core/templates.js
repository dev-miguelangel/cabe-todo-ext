import{titleCase as r}from"../utils/text.js";export const MAX_TEMPLATES=12;const l=`# {{titulo}}

## \u{1F4CB} Descripci\xF3n General
* **Como:** [Rol del usuario / tipo de usuario]
* **Quiero:** [Acci\xF3n o funcionalidad que necesita realizar]
* **Para que:** [Beneficio o valor de negocio que aporta]

---

## \u2705 Criterios de Aceptaci\xF3n (Definition of Ready / Done)
* [ ] **Criterio 1:** [Condici\xF3n inicial o requisito funcional que debe cumplirse]
* [ ] **Criterio 2:** [Validaci\xF3n de errores o casos borde esperados]
* [ ] **Criterio 3:** [Restricci\xF3n de dise\xF1o, rendimiento o seguridad]

---

## \u{1F6E0}\uFE0F Especificaciones T\xE9cnicas y Notas
* **Endpoints / APIs:** [Detallar rutas o servicios involucrados, si aplica]
* **Modelo de Datos:** [Cambios en base de datos, tablas o estructuras JSON]
* **Dependencias:** [Tareas o servicios previos necesarios]

---

## \u{1F4CC} Notas Adicionales
* [Cualquier detalle relevante, dise\xF1o UX/UI adjunto o restricciones del negocio]
`,c=`## Objetivo
[\xBFQu\xE9 se quiere lograr?]

## Notas


## Resultado

`;export const DEFAULT_TEMPLATES=[{id:"historia",name:"Historia de usuario",body:l},{id:"simple",name:"Simple",body:c}],DEFAULT_TEMPLATE_ID="historia";export function normalizeTemplates(o){const n=new Set,i=(Array.isArray(o)?o:[]).filter(e=>e&&typeof e.id=="string"&&typeof e.name=="string"&&typeof e.body=="string"&&e.name.trim()&&e.body.trim()&&!n.has(e.id)&&n.add(e.id)).slice(0,MAX_TEMPLATES).map(e=>({id:e.id,name:e.name.trim(),body:e.body}));return i.length?i:DEFAULT_TEMPLATES.map(e=>({...e}))}export function defaultTemplate(o,n){return o.find(i=>i.id===n)||o[0]}export function validateTemplates(o){if(!o.length)return"Necesitas al menos una plantilla.";if(o.length>MAX_TEMPLATES)return`Puedes tener hasta ${MAX_TEMPLATES} plantillas.`;const n=new Set;for(const i of o){const e=i.name.trim();if(!e)return"Cada plantilla necesita un nombre.";if(!i.body.trim())return`"${e}" est\xE1 vac\xEDa.`;const a=e.toLowerCase();if(n.has(a))return`Hay dos plantillas llamadas "${e}".`;n.add(a)}return null}export function fillTemplate(o,{title:n="",date:i="",epic:e=""}={}){const a={titulo:r(n),fecha:i,epica:e?r(e):""};return o.replace(/\{\{\s*(titulo|título|fecha|epica|épica)\s*\}\}/gi,(d,t)=>{const s=t.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"");return a[s]??""})}export function firstPlaceholder(o){const i=/\[(?![ xX]\])[^\]\n]{2,}\](?!\()/g.exec(o);return i?[i.index,i.index+i[0].length]:null}
