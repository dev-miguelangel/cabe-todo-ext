import{playCasio as e}from"../../services/casio.js";e(),chrome.runtime.onMessage.addListener(o=>{o?.type==="cabetodo-casio"&&e()});
