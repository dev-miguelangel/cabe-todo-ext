const d={h1:"# ",h2:"## ",h3:"### ",ul:"- ",task:"- [ ] ",quote:"> "},g={bold:{mark:"**",placeholder:"texto"},italic:{mark:"*",placeholder:"texto"},code:{mark:"`",placeholder:"c\xF3digo"}};function f(t,n,e){const l=t.lastIndexOf(`
`,n-1)+1,o=e>n&&t[e-1]===`
`?e-1:e;let i=t.indexOf(`
`,o);return i===-1&&(i=t.length),{start:l,end:i}}function p(t){return t.replace(/^(#{1,6}\s+|-\s\[[ xX]\]\s+|[-*+]\s+|>\s?)/,"")}function k(t,n,e,l){const{start:o,end:i}=f(t,n,e),c=t.slice(o,i).split(`
`),r=c.every(h=>h.startsWith(l)),s=c.map(h=>r?h.slice(l.length):l+p(h)).join(`
`),u=t.slice(0,o)+s+t.slice(i);if(n===e&&c.length===1){const h=o+s.length;return{text:u,start:h,end:h}}return{text:u,start:o,end:o+s.length}}function $(t,n,e,{mark:l,placeholder:o}){const i=t.slice(n,e);if(i&&t.slice(n-l.length,n)===l&&t.slice(e,e+l.length)===l)return{text:t.slice(0,n-l.length)+i+t.slice(e+l.length),start:n-l.length,end:e-l.length};const c=i||o;return{text:t.slice(0,n)+l+c+l+t.slice(e),start:n+l.length,end:n+l.length+c.length}}function T(t,n,e){const l=t.slice(n,e);if(l){const i=/^https?:\/\/\S+$/.test(l),c=i?"texto":l,r=i?l:"https://",a=`${t.slice(0,n)}[${c}](${r})${t.slice(e)}`,s=n+c.length+3;return i?{text:a,start:n+1,end:n+1+c.length}:{text:a,start:s,end:s+r.length}}return{text:`${t.slice(0,n)}[texto](https://)${t.slice(e)}`,start:n+1,end:n+6}}function B(t,n,e){const l=t.slice(n,e),o=n>0&&t[n-1]!==`
`?`
`:"",i=e<t.length&&t[e]!==`
`?`
`:"",c=l.replace(/\n$/,""),r=`${o}\`\`\`
${c}
\`\`\`${i}`,a=t.slice(0,n)+r+t.slice(e),s=n+o.length+4;return{text:a,start:s,end:s+c.length}}function b(t,n,e,l,o){const i=t.slice(0,n),c=t.slice(e),r=i?i.endsWith(`

`)?"":i.endsWith(`
`)?`
`:`

`:"",a=c?c.startsWith(`

`)?"":c.startsWith(`
`)?`
`:`

`:`
`,s=i+r+l+a+c,u=i.length+r.length;return o?{text:s,start:u+o[0],end:u+o[1]}:{text:s,start:u+l.length+a.length,end:u+l.length+a.length}}function C(t,n,e){return b(t,n,e,"---",null)}function L(t,n,e){const l=t.slice(n,e).replace(/\s*\n\s*/g," ").replace(/\|/g,"/").trim()||"Columna 1",o=`| ${l} | Columna 2 | Columna 3 |
| --- | --- | --- |
|  |  |  |`;return b(t,n,e,o,[2,2+l.length])}export function applyFormat(t,n,e,l){return d[l]?k(t,n,e,d[l]):g[l]?$(t,n,e,g[l]):l==="link"?T(t,n,e):l==="codeblock"?B(t,n,e):l==="hr"?C(t,n,e):l==="table"?L(t,n,e):{text:t,start:n,end:e}}export const TOOLBAR=[{kind:"h1",label:"H1",title:"T\xEDtulo 1"},{kind:"h2",label:"H2",title:"T\xEDtulo 2"},{kind:"h3",label:"H3",title:"T\xEDtulo 3"},{sep:!0},{kind:"bold",label:"B",title:"Negrita (\u2318B)",className:"tb-bold"},{kind:"italic",label:"I",title:"Cursiva (\u2318I)",className:"tb-italic"},{kind:"link",label:"Enlace",title:"Enlace (\u2318K)"},{sep:!0},{kind:"code",label:"`c\xF3digo`",title:"C\xF3digo en l\xEDnea"},{kind:"codeblock",label:"{ } Bloque",title:"Bloque de c\xF3digo"},{sep:!0},{kind:"ul",label:"\u2022 Lista",title:"Lista"},{kind:"task",label:"\u2610 Tareas",title:"Lista de tareas"},{kind:"quote",label:"\u275D Cita",title:"Cita"},{sep:!0},{kind:"table",label:"\u25A6 Tabla",title:"Tabla"},{kind:"hr",label:"\u2015 L\xEDnea",title:"L\xEDnea horizontal"}],SHORTCUTS={b:"bold",i:"italic",k:"link"};
