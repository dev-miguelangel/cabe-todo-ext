(()=>{if(window.__cabetodoFloatTimer||(window.__cabetodoFloatTimer=!0,typeof chrome>"u"||!chrome.storage?.local))return;const m="float_timer_min",f="float_meeting_min",b="float_meeting_dismissed",$=10,F=15*1e3;let p=[],w=!0,z=$*6e4;const L=(e={})=>{w=e.float_timer!==!1;const t=Number(e.meeting_lead);z=(Number.isFinite(t)&&t>=0?t:$)*6e4};let h=!1,k=!1,u=[],c=null,g=null;const l={};let d=null,S=null;const C=e=>{const t=e.time_entries||[];return t.length>0&&!t[t.length-1].end},B=(e,t)=>(e.time_entries||[]).reduce((n,i)=>{const o=Date.parse(i.start),r=i.end?Date.parse(i.end):t;return r>o?n+(r-o):n},0),y=e=>String(e).padStart(2,"0"),E=e=>{const t=Math.floor(e/1e3),n=Math.floor(t/3600);return n?`${n}:${y(Math.floor(t%3600/60))}:${y(t%60)}`:`${y(Math.floor(t/60))}:${y(t%60)}`},v=e=>E(Math.ceil(e/1e3)*1e3),T=(e,t)=>{const[n,i,o]=e.split("-").map(Number),[r,M]=t.split(":").map(Number);return new Date(n,i-1,o,r,M).getTime()},V=()=>p.find(e=>C(e)&&!e.meeting)||p.find(C);function Y(e){return p.filter(t=>t.meeting&&!t.done&&t.date&&!u.includes(t.id)).map(t=>({task:t,start:T(t.date,t.meeting.start),end:T(t.date,t.meeting.end)})).filter(t=>e>=t.start-z&&e<t.end).sort((t,n)=>t.start-n.start)[0]||null}const K=`
    :host { all: initial; }
    .stack {
      position: fixed; right: 16px; bottom: 16px; z-index: 2147483647;
      display: flex; flex-direction: column; align-items: flex-end; gap: 8px;
      font: 600 13px/1 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
    }
    .wrap {
      display: flex; align-items: center; gap: 2px; padding: 4px;
      border-radius: 999px; box-shadow: 0 6px 20px rgba(0,0,0,.35), 0 0 0 1px rgba(0,0,0,.15);
      color: #121212; background: #1db954;
      transition: transform .15s; animation: in .2s ease-out;
    }
    .wrap.over { background: #e5484d; color: #fff; }
    .wrap.meeting { background: #4fc3f7; color: #06232f; }
    .wrap:hover { transform: translateY(-1px); }
    button {
      all: unset; box-sizing: border-box; cursor: pointer; color: inherit;
      display: inline-flex; align-items: center; justify-content: center;
      border-radius: 999px; height: 32px;
    }
    button:focus-visible { outline: 2px solid currentColor; outline-offset: 1px; }
    .main { gap: 8px; padding: 0 12px 0 10px; max-width: 300px; }
    .main:hover, .icon:hover { background: rgba(0,0,0,.12); }
    .over .main:hover, .over .icon:hover { background: rgba(255,255,255,.18); }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: currentColor; flex: none; animation: blink 1s steps(1) infinite; }
    .label { font-weight: 600; opacity: .85; white-space: nowrap; }
    .time { font-size: 15px; font-weight: 700; font-variant-numeric: tabular-nums; letter-spacing: .01em; }
    .title { font-weight: 500; opacity: .85; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; }
    .icon { width: 32px; font-size: 12px; }
    .pause { gap: 3px; }
    .pause::before, .pause::after { content: ""; width: 3px; height: 12px; border-radius: 1px; background: currentColor; }
    .stop::before { content: ""; width: 11px; height: 11px; border-radius: 2px; background: currentColor; }
    .play::before { content: ""; border-style: solid; border-width: 6px 0 6px 10px; border-color: transparent transparent transparent currentColor; margin-left: 2px; }
    .close { font-size: 16px; opacity: .75; }
    .close:hover { opacity: 1; }
    /* Minimizado: solo un c\xEDrculo que parpadea */
    .expand { display: none; width: 28px; height: 28px; }
    .expand::before { content: ""; width: 12px; height: 12px; border-radius: 50%; background: currentColor; animation: blink 1s steps(1) infinite; }
    .wrap.min { padding: 4px; gap: 0; }
    .wrap.min > :not(.expand) { display: none; }
    .wrap.min .expand { display: inline-flex; }
    [hidden] { display: none !important; }
    @keyframes blink { 50% { opacity: .25; } }
    @keyframes in { from { opacity: 0; transform: translateY(8px); } }
    @media (prefers-reduced-motion: reduce) { .dot, .expand::before, .wrap { animation: none; } }
  `;function s(e,t,n={}){const i=document.createElement(e);t&&(i.className=t);for(const[o,r]of Object.entries(n))i.setAttribute(o,r);return i}function H(){if(c)return;c=document.createElement("cabetodo-timer");const e=c.attachShadow({mode:"closed"}),t=document.createElement("style");t.textContent=K,g=s("div","stack"),e.append(t,g),(document.body||document.documentElement).append(c)}function D(){c?.remove(),c=null,g=null,delete l.timer,delete l.meeting,clearInterval(d),d=null}function R(e){const t=s("div",`wrap${e==="meeting"?" meeting":""}`,{role:"timer","aria-live":"off"}),n=s("button","main",{type:"button",title:"Abrir Cabe Todo"}),i=s("span","dot",{"aria-hidden":"true"}),o=s("span","label"),r=s("span","time"),M=s("span","title");n.append(i,o,r,M);const a={kind:e,wrap:t,main:n,label:o,time:r,title:M};return n.addEventListener("click",()=>I({type:"cabetodo-open-panel"})),t.append(n),e==="timer"?(a.pause=s("button","icon pause",{type:"button",title:"Pausar","aria-label":"Pausar temporizador"}),a.pause.addEventListener("click",()=>I({type:"cabetodo-pause-timer"})),a.stop=s("button","icon stop",{type:"button",title:"Finalizar reuni\xF3n","aria-label":"Finalizar reuni\xF3n"}),a.stop.addEventListener("click",()=>a.taskId&&I({type:"cabetodo-finish-meeting",taskId:a.taskId})),t.append(a.pause,a.stop)):(a.play=s("button","icon play",{type:"button",title:"Iniciar temporizador de la reuni\xF3n","aria-label":"Iniciar temporizador de la reuni\xF3n"}),a.play.addEventListener("click",()=>a.taskId&&I({type:"cabetodo-start-timer",taskId:a.taskId})),t.append(a.play)),a.close=s("button","icon close",{type:"button"}),a.close.textContent="\xD7",a.close.addEventListener("click",()=>{e==="meeting"&&a.started?j(a.taskId):N(e,!0)}),a.expand=s("button","expand",{type:"button","aria-label":"Mostrar"}),a.expand.addEventListener("click",()=>N(e,!1)),t.append(a.close,a.expand),a}function N(e,t){e==="timer"?h=t:k=t;const n=l[e];n&&(_(),(t?n.expand:n.main).focus()),A({[e==="timer"?m:f]:t})}function j(e){u=[...u.filter(t=>p.some(n=>n.id===t)),e],x(),A({[b]:u})}function A(e){try{chrome.storage.local.set(e)}catch{}}function I(e){try{chrome.runtime.sendMessage(e)}catch{D()}}function q(e,t,n){e.taskId=t.id,e.pause.hidden=!!t.meeting,e.stop.hidden=!t.meeting;const i=(t.minutes||0)*6e4-B(t,n),o=i<=0;e.wrap.classList.toggle("over",o),e.wrap.classList.toggle("min",h),e.label.hidden=!0,e.time.textContent=o?`+${E(-i)}`:v(i),e.title.textContent=t.title;const r=o?`${t.title}: tiempo cumplido, ${E(-i)} extra`:`${t.title}: quedan ${v(i)}`;e.wrap.setAttribute("aria-label",r),e.main.title=`${t.title} \xB7 ${o?"tiempo cumplido":"cuenta atr\xE1s"} \xB7 clic para abrir Cabe Todo`,e.close.title="Minimizar",e.close.setAttribute("aria-label","Minimizar temporizador"),e.expand.title=`${r} \xB7 clic para mostrar`}function P(e,t,n){const i=n>=t.start;e.taskId=t.task.id,e.started=i,e.wrap.classList.toggle("min",k),e.label.hidden=!1,e.label.textContent=i?"\u25F7 Empez\xF3":"\u25F7 En",e.time.hidden=i,e.time.textContent=i?"":v(t.start-n),e.title.textContent=t.task.title,e.play.hidden=!i||C(t.task);const o=`${t.task.meeting.start}\u2013${t.task.meeting.end}`,r=i?`La reuni\xF3n "${t.task.title}" empez\xF3 (${o})`:`La reuni\xF3n "${t.task.title}" empieza en ${v(t.start-n)} (${o})`;e.wrap.setAttribute("aria-label",r),e.main.title=`${r} \xB7 clic para abrir Cabe Todo`,e.close.title=i?"Cerrar":"Minimizar",e.close.setAttribute("aria-label",i?"Cerrar aviso de reuni\xF3n":"Minimizar aviso de reuni\xF3n"),e.expand.title=`${r} \xB7 clic para mostrar`}function _(){const e=Date.now(),t=w?V():null,n=w?Y(e):null;if(!t&&!n)return D(),!1;H();for(const[i,o]of[["meeting",n],["timer",t]]){if(!o){l[i]?.wrap.remove(),delete l[i];continue}l[i]||(l[i]=R(i),i==="meeting"?g.prepend(l[i].wrap):g.append(l[i].wrap)),i==="timer"?q(l.timer,o,e):P(l.meeting,o,e)}return!0}function x(){const e=_();e&&!d&&document.visibilityState==="visible"&&(d=setInterval(_,1e3)),e||(clearInterval(d),d=null)}function U(){clearInterval(S),S=setInterval(()=>{!c&&document.visibilityState==="visible"&&x()},F)}document.addEventListener("visibilitychange",()=>{clearInterval(d),d=null,document.visibilityState==="visible"&&x()}),chrome.storage.local.get(["tasks","settings",m,f,b]).then(e=>{p=e.tasks||[],L(e.settings||{}),h=!!e[m],k=!!e[f],u=e[b]||[],x(),U()}),chrome.storage.onChanged.addListener((e,t)=>{if(t!=="local")return;let n=!1;e.tasks&&(p=e.tasks.newValue||[],n=!0),e.settings&&(L(e.settings.newValue||{}),n=!0),e[m]&&(h=!!e[m].newValue,n=!0),e[f]&&(k=!!e[f].newValue,n=!0),e[b]&&(u=e[b].newValue||[],n=!0),n&&x()})})();
